CREATE PROCEDURE createTempTableKLADR()
  BEGIN
    DROP TEMPORARY TABLE IF EXISTS kladr_temp;
    CREATE TEMPORARY TABLE kladr_temp(
      id int(11) NOT NULL AUTO_INCREMENT,
      name varchar(255) NOT NULL,
      code varchar(255) NOT NULL,
      full_code varchar(255) NOT NULL,
      obj_id int(11) NOT NULL DEFAULT -1,
      type_id int(11) NOT NULL, PRIMARY KEY (id)
    ) ENGINE=InnoDB;
  END;
