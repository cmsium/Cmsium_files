CREATE PROCEDURE getTableNamesWith(IN columnName VARCHAR(64))
  BEGIN
    SELECT table_name AS name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name LIKE 'event\_%' AND NOT table_name='event_destroy_confirmation' AND NOT table_name='event_types'  AND column_name = columnName;
  END;
