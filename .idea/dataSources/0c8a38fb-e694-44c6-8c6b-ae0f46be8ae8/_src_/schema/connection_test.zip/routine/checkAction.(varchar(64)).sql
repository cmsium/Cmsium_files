CREATE PROCEDURE checkAction(IN ActionName VARCHAR(64))
  BEGIN
    SELECT action_id FROM system_actions WHERE name=ActionName;
END;
