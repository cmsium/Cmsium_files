CREATE PROCEDURE getDocumentTypes()
  BEGIN
    SELECT * FROM document_types;
  END;
