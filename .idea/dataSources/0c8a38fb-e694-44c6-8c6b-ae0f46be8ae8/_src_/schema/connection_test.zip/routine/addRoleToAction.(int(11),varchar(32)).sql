CREATE PROCEDURE addRoleToAction(IN idRole INT, IN idAction VARCHAR(32))
  BEGIN
    INSERT INTO roles_in_actions (id_role, action_id) VALUES (idRole,idAction);
END;
