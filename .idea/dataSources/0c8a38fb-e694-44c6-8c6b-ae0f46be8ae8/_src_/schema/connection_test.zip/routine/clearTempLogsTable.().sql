CREATE PROCEDURE clearTempLogsTable()
  BEGIN
    DROP TABLE IF EXISTS system_log_temp; 
  END;
