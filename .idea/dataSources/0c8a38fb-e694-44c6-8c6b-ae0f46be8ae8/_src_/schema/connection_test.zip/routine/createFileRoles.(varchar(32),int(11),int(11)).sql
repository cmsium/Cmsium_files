CREATE PROCEDURE createFileRoles(IN idFile VARCHAR(32), IN idRole INT, IN inPermissions INT)
  BEGIN
     INSERT INTO roles_in_files (role_id, file_id, permissions) VALUES (idRole, idFile,inPermissions);
END;
