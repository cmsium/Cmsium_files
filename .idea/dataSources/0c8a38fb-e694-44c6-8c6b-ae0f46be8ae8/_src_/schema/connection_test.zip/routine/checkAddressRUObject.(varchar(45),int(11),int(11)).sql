CREATE PROCEDURE checkAddressRUObject(IN addressName VARCHAR(45), IN idParent INT, IN idType INT)
  BEGIN
    SELECT id FROM address_ru WHERE name = addressName AND parent_id = idParent AND type_id = idType;
  END;
