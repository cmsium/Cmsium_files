CREATE PROCEDURE getFileIdByLink(IN inLink VARCHAR(32))
  BEGIN
     SELECT file_id FROM file_links WHERE link=inLink;
END;
