CREATE PROCEDURE deleteDocumentTable(IN typeName VARCHAR(64))
  BEGIN
    START TRANSACTION;
    SET @sql = CONCAT ('DROP TABLE IF EXISTS ',CONCAT('document_',typeName));
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    DELETE FROM document_types WHERE name = typeName;
    COMMIT;
  END;
