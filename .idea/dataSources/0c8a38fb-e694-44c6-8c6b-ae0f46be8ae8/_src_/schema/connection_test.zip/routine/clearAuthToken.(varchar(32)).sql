CREATE PROCEDURE clearAuthToken(IN authToken VARCHAR(32))
  BEGIN
    DELETE FROM auth_tokens WHERE token = authToken;
  END;
