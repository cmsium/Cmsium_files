CREATE PROCEDURE getRoleData(IN idRole INT)
  BEGIN
  SELECT * FROM roles WHERE id = idRole;
END;
