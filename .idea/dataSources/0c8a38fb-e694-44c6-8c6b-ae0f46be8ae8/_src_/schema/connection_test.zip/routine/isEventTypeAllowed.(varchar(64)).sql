CREATE PROCEDURE isEventTypeAllowed(IN typeName VARCHAR(64))
  BEGIN
    SELECT name FROM event_types WHERE name=typeName;
  END;
