CREATE PROCEDURE getRowFromKLADRTemp(IN idRow INT)
  BEGIN
    SELECT * FROM kladr_temp WHERE id = idRow;
  END;
