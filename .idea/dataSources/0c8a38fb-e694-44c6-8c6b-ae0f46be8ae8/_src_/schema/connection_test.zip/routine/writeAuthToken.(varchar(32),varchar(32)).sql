CREATE PROCEDURE writeAuthToken(IN idUser VARCHAR(32), IN userToken VARCHAR(32))
  BEGIN
    CALL clearAuthTokenById(idUser);
    INSERT INTO auth_tokens(user_id, token) VALUES (idUser, userToken);
  END;
