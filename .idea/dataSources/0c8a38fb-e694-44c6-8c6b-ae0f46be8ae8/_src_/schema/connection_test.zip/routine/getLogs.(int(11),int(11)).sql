CREATE PROCEDURE getLogs(IN Start INT, IN myOffset INT)
  BEGIN
    SELECT * FROM system_log LIMIT Start,myOffset;
  END;
