CREATE PROCEDURE getActionRoles(IN Action VARCHAR(32))
  BEGIN
    SELECT GROUP_CONCAT(DISTINCT id_role SEPARATOR ',') as roles FROM roles_in_actions WHERE action_id=Action;
END;
