CREATE PROCEDURE getAllDocuments(IN typeName VARCHAR(255))
  BEGIN
    START TRANSACTION;
    SET @sql = CONCAT('SELECT * FROM ',CONCAT('document_',typeName), ';');
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    COMMIT;
  END;
