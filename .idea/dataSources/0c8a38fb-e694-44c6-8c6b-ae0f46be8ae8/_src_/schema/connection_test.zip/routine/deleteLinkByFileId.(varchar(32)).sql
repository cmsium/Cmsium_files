CREATE PROCEDURE deleteLinkByFileId(IN idFile VARCHAR(32))
  BEGIN
    DELETE FROM file_links WHERE file_id=idFile;
  END;
