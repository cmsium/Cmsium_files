CREATE PROCEDURE getBasicActionData(IN BasicAction VARCHAR(32))
  BEGIN
    SELECT * FROM event_basic_actions WHERE baction_id = BasicAction;
  END;
