CREATE PROCEDURE addTableReference(IN tableName VARCHAR(255), IN columnName VARCHAR(255), IN moduleName VARCHAR(255))
  BEGIN
    INSERT INTO system_references VALUES(tableName, columnName, moduleName);
  END;
