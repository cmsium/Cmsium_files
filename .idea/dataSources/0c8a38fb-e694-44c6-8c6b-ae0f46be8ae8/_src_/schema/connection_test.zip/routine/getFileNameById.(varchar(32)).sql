CREATE PROCEDURE getFileNameById(IN idFile VARCHAR(32))
  BEGIN
    SELECT name FROM files WHERE file_id = idFile ;
  END;
