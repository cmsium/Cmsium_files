CREATE PROCEDURE getEventTypes()
  BEGIN
    SELECT * FROM event_types WHERE system_flag IS NULL;
  END;
