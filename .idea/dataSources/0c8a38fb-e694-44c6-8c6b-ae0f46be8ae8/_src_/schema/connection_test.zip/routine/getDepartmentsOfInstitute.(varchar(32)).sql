CREATE PROCEDURE getDepartmentsOfInstitute(IN InstituteId VARCHAR(32))
  BEGIN
    SELECT * FROM departments LEFT JOIN departments_in_institutes
    ON departments.department_id = departments_in_institutes.department_id 
    WHERE departments_in_institutes.institute_id = InstituteId;
  END;
