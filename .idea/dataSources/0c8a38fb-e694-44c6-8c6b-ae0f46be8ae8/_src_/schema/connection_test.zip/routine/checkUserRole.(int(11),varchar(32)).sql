CREATE PROCEDURE checkUserRole(IN idRole INT, IN idUser VARCHAR(32))
  BEGIN
    SELECT role_id FROM roles_in_users WHERE role_id = idRole AND user_id = idUser;
  END;
