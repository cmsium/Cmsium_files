CREATE PROCEDURE writeAddressRUObject(IN addressName VARCHAR(45), IN idParent INT, IN idType INT)
  BEGIN
    INSERT INTO address_ru(name, parent_id, type_id) VALUES (addressName,idParent,idType);
    SELECT last_insert_id() as id;
  END;
