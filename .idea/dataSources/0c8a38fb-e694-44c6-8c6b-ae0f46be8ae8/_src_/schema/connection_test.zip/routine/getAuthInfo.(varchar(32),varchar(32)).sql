CREATE PROCEDURE getAuthInfo(IN idUser VARCHAR(32), IN authToken VARCHAR(32))
  BEGIN
    SELECT user_id, token, created_at FROM auth_tokens WHERE user_id = idUser AND token = authToken;
  END;
