CREATE PROCEDURE clearDocumentExpiredConfirmations()
  BEGIN
    DELETE FROM document_destroy_confirmation WHERE document_destroy_confirmation.expires < NOW();
  END;
