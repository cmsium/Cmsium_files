CREATE PROCEDURE checkFileLink(IN idFile VARCHAR(32))
  BEGIN
     SELECT link FROM file_links WHERE file_id=idFile;
END;
