CREATE PROCEDURE createTempLogsTable()
  BEGIN
    CREATE TABLE system_log_temp LIKE system_log;
  END;
