CREATE PROCEDURE clearLogs()
  BEGIN
    DELETE FROM system_log;
  END;
