CREATE PROCEDURE getTableReference(IN tableName VARCHAR(64))
  BEGIN
    SELECT table_name, column_name, module_name
    FROM system_references WHERE table_name = tableName;
  END;
