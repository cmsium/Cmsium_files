CREATE PROCEDURE getObjIDFromKLADRTempByCode(IN codeVal VARCHAR(255), IN idType INT)
  BEGIN
    SELECT obj_id FROM kladr_temp WHERE code = codeVal AND type_id = idType;
  END;
