CREATE PROCEDURE addObjectIDToKLADRTemp(IN idObj INT, IN idKLADRRow INT)
  BEGIN
    UPDATE kladr_temp SET obj_id = idObj WHERE id = idKLADRRow;
  END;
