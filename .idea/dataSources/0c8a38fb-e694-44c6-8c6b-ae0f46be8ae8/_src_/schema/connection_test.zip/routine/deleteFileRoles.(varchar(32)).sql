CREATE PROCEDURE deleteFileRoles(IN idFile VARCHAR(32))
  BEGIN
     DELETE FROM roles_in_files WHERE file_id=idFile;
END;
