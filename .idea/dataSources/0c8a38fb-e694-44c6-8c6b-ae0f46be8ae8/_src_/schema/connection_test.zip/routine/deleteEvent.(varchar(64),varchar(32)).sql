CREATE PROCEDURE deleteEvent(IN tableName VARCHAR(64), IN idEvent VARCHAR(32))
  BEGIN
    SET @sql = CONCAT('DELETE FROM ',
                      tableName,
                      ' WHERE event_id="',
                      idEvent,
                      '";');
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END;
