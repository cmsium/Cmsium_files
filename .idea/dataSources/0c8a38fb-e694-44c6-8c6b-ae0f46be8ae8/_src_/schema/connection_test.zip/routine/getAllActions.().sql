CREATE PROCEDURE getAllActions()
  BEGIN
    SELECT action_id,name FROM system_actions;
END;
