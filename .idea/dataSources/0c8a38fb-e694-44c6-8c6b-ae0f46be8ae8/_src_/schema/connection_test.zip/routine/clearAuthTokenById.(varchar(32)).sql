CREATE PROCEDURE clearAuthTokenById(IN idUser VARCHAR(32))
  BEGIN
    DELETE FROM auth_tokens WHERE user_id = idUser;
  END;
