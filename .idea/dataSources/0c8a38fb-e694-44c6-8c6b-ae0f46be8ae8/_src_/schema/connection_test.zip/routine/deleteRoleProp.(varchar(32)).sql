CREATE PROCEDURE deleteRoleProp(IN ROLE VARCHAR(32))
  BEGIN
    SET @sql = CONCAT ('DROP TABLE IF EXISTS ',CONCAT(Role,'_properties'));
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END;
