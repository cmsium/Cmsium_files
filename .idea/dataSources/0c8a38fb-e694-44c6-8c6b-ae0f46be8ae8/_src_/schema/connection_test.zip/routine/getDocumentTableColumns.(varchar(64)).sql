CREATE PROCEDURE getDocumentTableColumns(IN tableName VARCHAR(64))
  BEGIN
    SELECT column_name, column_type, is_nullable, column_key
    FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = CONCAT('document_', tableName);
  END;
