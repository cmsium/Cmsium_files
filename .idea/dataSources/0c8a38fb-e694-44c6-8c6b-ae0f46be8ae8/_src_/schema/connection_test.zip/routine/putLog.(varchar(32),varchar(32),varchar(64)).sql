CREATE PROCEDURE putLog(IN Action VARCHAR(32), IN idUser VARCHAR(32), IN Status VARCHAR(64))
  BEGIN
    INSERT INTO system_log (id,action,user_id,created_at,status) VALUES (md5(CONCAT(Action,idUser,NOW())),Action,idUser,NOW(),Status);
END;
