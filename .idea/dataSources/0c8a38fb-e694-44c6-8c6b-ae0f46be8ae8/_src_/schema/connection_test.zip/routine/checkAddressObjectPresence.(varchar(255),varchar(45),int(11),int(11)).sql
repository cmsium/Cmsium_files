CREATE PROCEDURE checkAddressObjectPresence(IN tableName VARCHAR(255), IN objectName VARCHAR(45), IN idParent INT,
                                            IN idType    INT)
  BEGIN
    SET @sql = CONCAT('SELECT id FROM ',
                      tableName,
                      ' WHERE name = "',
                      objectName,
                      '" AND parent_id = ',
                      idParent,
                      ' AND type_id = ',
                      idType,
                      ';');
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END;
