CREATE PROCEDURE getAllDepartments()
  BEGIN
    SELECT * FROM departments;
  END;
